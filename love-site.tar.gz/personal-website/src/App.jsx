import { useState, useEffect } from 'react'
import './App.css'

function App() {
  const [activePage, setActivePage] = useState('home');
  const [isAdmin, setIsAdmin] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [adminContent, setAdminContent] = useState({
    about: '关于我',
    projects: [
      { id: 1, title: '项目1', description: '项目1描述' },
      { id: 2, title: '项目2', description: '项目2描述' }
    ],
    countdown: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    avatar1: '',
    avatar2: '',
    avatar1Name: '',
    avatar2Name: '',
    album: []
  });
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [countdownTime, setCountdownTime] = useState('00:00:00:00');
  const [countdownDate, setCountdownDate] = useState(new Date(adminContent.countdown));
  const [messages, setMessages] = useState([]);
  const [messageName, setMessageName] = useState('');
  const [messageContent, setMessageContent] = useState('');
  const [isMessagesOpen, setIsMessagesOpen] = useState(false);

  // 从后端获取内容
  useEffect(() => {
    const fetchContent = async () => {
      try {
        const response = await fetch('/api/content');
        const data = await response.json();
        if (data) {
          setAdminContent(data);
          setCountdownDate(new Date(data.countdown));
        }
      } catch (error) {
        console.error('获取内容失败:', error);
      }
    };

    fetchContent();
  }, []);

  // 从后端获取留言
  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const response = await fetch('/api/messages');
        const data = await response.json();
        setMessages(data);
      } catch (error) {
        console.error('获取留言失败:', error);
      }
    };

    fetchMessages();
  }, []);

  // 倒计时逻辑（计算从起始时间到现在的时间）
  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const distance = now - countdownDate;

      if (distance < 0) {
        setCountdownTime('00:00:00:00');
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      setCountdownTime(`${String(days).padStart(2, '0')}:${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, [countdownDate]);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });
      const data = await response.json();
      if (data.token) {
        setIsAdmin(true);
        localStorage.setItem('token', data.token);
        alert('登录成功！');
      } else {
        alert(data.message || '登录失败，请检查用户名和密码');
      }
    } catch (error) {
      console.error('登录失败:', error);
      alert('网络错误，请检查后端服务是否启动');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    setUsername('');
    setPassword('');
    localStorage.removeItem('token');
  };

  const handleContentChange = (e) => {
    const { name, value } = e.target;
    setAdminContent(prev => ({
      ...prev,
      [name]: value
    }));
    if (name === 'countdown') {
      setCountdownDate(new Date(value));
    }
  };

  // 处理文件上传
  const handleAvatarUpload = async (file, avatarField) => {
    try {
      const formData = new FormData();
      formData.append('avatar', file);
      
      const response = await fetch('/api/upload-avatar', {
        method: 'POST',
        body: formData
      });
      
      const data = await response.json();
      if (data.url) {
        setAdminContent(prev => ({
          ...prev,
          [avatarField]: data.url
        }));
        alert('头像上传成功');
      }
    } catch (error) {
      console.error('上传失败:', error);
      alert('上传失败');
    }
  };

  // 处理提交留言
  const handleSubmitMessage = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: messageName,
          content: messageContent
        })
      });
      
      const data = await response.json();
      if (data.id) {
        setMessages(prev => [...prev, data]);
        setMessageName('');
        setMessageContent('');
        alert('留言提交成功');
      }
    } catch (error) {
      console.error('提交留言失败:', error);
      alert('提交留言失败');
    }
  };

  // 处理相册照片上传
  const handleAlbumPhotoUpload = async (file) => {
    try {
      const formData = new FormData();
      formData.append('avatar', file);
      
      const response = await fetch('/api/upload-avatar', {
        method: 'POST',
        body: formData
      });
      
      const data = await response.json();
      if (data.url) {
        setAdminContent(prev => ({
          ...prev,
          album: [...prev.album, { url: data.url }]
        }));
        alert('照片上传成功');
      }
    } catch (error) {
      console.error('上传失败:', error);
      alert('上传失败');
    }
  };

  // 处理删除留言
  const handleDeleteMessage = async (messageId) => {
    try {
      if (confirm('确定要删除这条留言吗？')) {
        const response = await fetch(`/api/messages/${messageId}`, {
          method: 'DELETE'
        });
        
        const data = await response.json();
        if (data.message === '留言删除成功') {
          setMessages(prev => prev.filter(message => message.id !== messageId));
          alert('留言删除成功');
        }
      }
    } catch (error) {
      console.error('删除留言失败:', error);
      alert('删除留言失败');
    }
  };

  const handleSaveContent = async () => {
    try {
      const response = await fetch('/api/content', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(adminContent)
      });
      const data = await response.json();
      if (data) {
        alert('保存成功');
      }
    } catch (error) {
      console.error('保存失败:', error);
    }
  };

  const renderPage = () => {
    switch (activePage) {
      case 'home':
        return (
          <section id="home">
            <div className="avatars">
              <div className="avatar-container">
                <div className="avatar">
                  {adminContent.avatar1 ? (
                    <img src={adminContent.avatar1} alt="头像1" />
                  ) : (
                    <div className="avatar-placeholder">头像1</div>
                  )}
                </div>
                <div className="avatar-name">{adminContent.avatar1Name || '名字1'}</div>
              </div>
              <div className="heart">
                <svg width="60" height="54" viewBox="0 0 60 54" fill="none">
                  <path d="M30 54C30 54 0 36 0 18C0 8 8 0 18 0C24 0 28 4 30 8C32 4 36 0 42 0C52 0 60 8 60 18C60 36 30 54 30 54Z" fill="#ff2d55"/>
                </svg>
              </div>
              <div className="avatar-container">
                <div className="avatar">
                  {adminContent.avatar2 ? (
                    <img src={adminContent.avatar2} alt="头像2" />
                  ) : (
                    <div className="avatar-placeholder">头像2</div>
                  )}
                </div>
                <div className="avatar-name">{adminContent.avatar2Name || '名字2'}</div>
              </div>
            </div>
            <div className="countdown">
              <h2>我们已经一起度过了</h2>
              <div className="countdown-display">
                {countdownTime}
              </div>
              <div className="countdown-labels">
                <span>天</span>
                <span>时</span>
                <span>分</span>
                <span>秒</span>
              </div>
            </div>
            <div className="home-messages">
              <div className="home-messages-toggle" onClick={() => setIsMessagesOpen(!isMessagesOpen)}>
                <h2>留言板</h2>
                <span className="toggle-icon">{isMessagesOpen ? '▲' : '▼'}</span>
              </div>
              {isMessagesOpen && (
              <div className="messages-container">
                <div className="messages-list">
                  {messages.map(message => (
                    <div key={message.id} className="message-item">
                      <div className="message-header">
                        <span className="message-name">{message.name}</span>
                        <span className="message-time">{new Date(message.createdAt).toLocaleString()}</span>
                      </div>
                      <div className="message-content">{message.content}</div>
                    </div>
                  ))}
                </div>
                <div className="message-form">
                  <h3>发表留言</h3>
                  <form onSubmit={handleSubmitMessage}>
                    <div className="form-group">
                      <label htmlFor="homeMessageName">姓名</label>
                      <input
                        type="text"
                        id="homeMessageName"
                        value={messageName}
                        onChange={(e) => setMessageName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="homeMessageContent">留言内容</label>
                      <textarea
                        id="homeMessageContent"
                        value={messageContent}
                        onChange={(e) => setMessageContent(e.target.value)}
                        rows={4}
                        required
                      ></textarea>
                    </div>
                    <button type="submit">提交留言</button>
                  </form>
                </div>
              </div>
              )}
            </div>
          </section>
        );
      case 'about':
        return (
          <section id="about">
            <h2>关于我</h2>
            <p>{adminContent.about}</p>
          </section>
        );
      case 'projects':
        return (
          <section id="projects">
            <h2>我的项目</h2>
            <div className="projects-list">
              {adminContent.projects.map(project => (
                <div key={project.id} className="project-item">
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                </div>
              ))}
            </div>
          </section>
        );
      case 'album':
        return (
          <section id="album">
            <h2>相册</h2>
            <div className="album-grid">
              {adminContent.album.map((photo, index) => (
                <div key={index} className="album-item">
                  <img src={photo.url} alt={photo.title || `照片${index + 1}`} />
                  {photo.title && <p className="photo-title">{photo.title}</p>}
                </div>
              ))}
            </div>
          </section>
        );
      case 'messages':
        return (
          <section id="messages">
            <h2>留言板</h2>
            <div className="messages-container">
              <div className="messages-list">
                {messages.map(message => (
                  <div key={message.id} className="message-item">
                    <div className="message-header">
                      <span className="message-name">{message.name}</span>
                      <span className="message-time">{new Date(message.createdAt).toLocaleString()}</span>
                    </div>
                    <div className="message-content">{message.content}</div>
                  </div>
                ))}
              </div>
              <div className="message-form">
                <h3>发表留言</h3>
                <form onSubmit={handleSubmitMessage}>
                  <div className="form-group">
                    <label htmlFor="messageName">姓名</label>
                    <input
                      type="text"
                      id="messageName"
                      value={messageName}
                      onChange={(e) => setMessageName(e.target.value)}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="messageContent">留言内容</label>
                    <textarea
                      id="messageContent"
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      rows={4}
                      required
                    ></textarea>
                  </div>
                  <button type="submit">提交留言</button>
                </form>
              </div>
            </div>
          </section>
        );
      case 'admin':
        if (!isAdmin) {
          return (
            <section id="admin">
              <h2>管理员登录</h2>
              <form onSubmit={handleLogin} className="login-form">
                <div className="form-group">
                  <label htmlFor="username">用户名</label>
                  <input
                    type="text"
                    id="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="password">密码</label>
                  <input
                    type="password"
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                <button type="submit">登录</button>
              </form>
            </section>
          );
        }
        return (
          <section id="admin">
            <h2>后台管理</h2>
            <button onClick={handleLogout}>退出登录</button>
            <div className="admin-panel">
              <h3>编辑关于我</h3>
              <form className="content-form">
                <div className="form-group">
                  <label htmlFor="about">内容</label>
                  <textarea
                    id="about"
                    name="about"
                    value={adminContent.about}
                    onChange={handleContentChange}
                    rows={5}
                  ></textarea>
                </div>
                <button type="button" onClick={handleSaveContent}>保存</button>
              </form>
            </div>
            <div className="admin-panel">
              <h3>编辑起始时间</h3>
              <form className="content-form">
                <div className="form-group">
                  <label htmlFor="countdown">起始时间</label>
                  <input
                    type="datetime-local"
                    id="countdown"
                    name="countdown"
                    value={adminContent.countdown ? new Date(adminContent.countdown).toISOString().slice(0, 16) : ''}
                    onChange={handleContentChange}
                  />
                </div>
                <button type="button" onClick={handleSaveContent}>保存</button>
              </form>
            </div>
            <div className="admin-panel">
              <h3>编辑项目</h3>
              {/* 项目编辑功能可以在这里添加 */}
            </div>
            <div className="admin-panel">
              <h3>编辑相册</h3>
              <form className="content-form">
                <div className="album-preview">
                  {adminContent.album.map((photo, index) => (
                    <div key={index} className="album-item-preview">
                      <img src={photo.url} alt={photo.title || `照片${index + 1}`} />
                      {photo.title && <p>{photo.title}</p>}
                      <button type="button" onClick={() => {
                        setAdminContent(prev => ({
                          ...prev,
                          album: prev.album.filter((_, i) => i !== index)
                        }));
                      }}>删除</button>
                    </div>
                  ))}
                </div>
                <div className="form-group">
                  <label htmlFor="albumPhotoUpload">添加照片</label>
                  <input
                    type="file"
                    id="albumPhotoUpload"
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files[0]) {
                        handleAlbumPhotoUpload(e.target.files[0]);
                      }
                    }}
                  />
                </div>
                <button type="button" onClick={handleSaveContent}>保存相册</button>
              </form>
            </div>
            <div className="admin-panel">
              <h3>留言管理</h3>
              <div className="messages-list">
                {messages.map(message => (
                  <div key={message.id} className="message-item">
                    <div className="message-header">
                      <span className="message-name">{message.name}</span>
                      <span className="message-time">{new Date(message.createdAt).toLocaleString()}</span>
                      <button type="button" onClick={() => handleDeleteMessage(message.id)}>删除</button>
                    </div>
                    <div className="message-content">{message.content}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="admin-panel">
              <h3>编辑头像</h3>
              <form className="content-form">
                <div className="form-group">
                  <label htmlFor="avatar1Upload">头像1</label>
                  {adminContent.avatar1 && (
                    <div className="avatar-preview">
                      <img src={adminContent.avatar1} alt="头像1预览" style={{ width: '80px', height: '80px', borderRadius: '50%' }} />
                    </div>
                  )}
                  <input
                    type="file"
                    id="avatar1Upload"
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files[0]) {
                        handleAvatarUpload(e.target.files[0], 'avatar1');
                      }
                    }}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="avatar1Name">头像1名字</label>
                  <input
                    type="text"
                    id="avatar1Name"
                    name="avatar1Name"
                    value={adminContent.avatar1Name}
                    onChange={handleContentChange}
                    placeholder="输入头像名字"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="avatar2Upload">头像2</label>
                  {adminContent.avatar2 && (
                    <div className="avatar-preview">
                      <img src={adminContent.avatar2} alt="头像2预览" style={{ width: '80px', height: '80px', borderRadius: '50%' }} />
                    </div>
                  )}
                  <input
                    type="file"
                    id="avatar2Upload"
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files[0]) {
                        handleAvatarUpload(e.target.files[0], 'avatar2');
                      }
                    }}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="avatar2Name">头像2名字</label>
                  <input
                    type="text"
                    id="avatar2Name"
                    name="avatar2Name"
                    value={adminContent.avatar2Name}
                    onChange={handleContentChange}
                    placeholder="输入头像名字"
                  />
                </div>
                <button type="button" onClick={handleSaveContent}>保存</button>
              </form>
            </div>
          </section>
        );
      default:
        return (
          <section id="home">
            <h1>欢迎来到我的个人网站</h1>
          </section>
        );
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div className="App">
      <header>
        <nav>
          <div className="header-content">
            <h1>欢迎来到我的个人网站</h1>
          </div>
          <button className={`menu-toggle ${isMenuOpen ? 'open' : ''}`} onClick={toggleMenu}>
            <span></span>
            <span></span>
            <span></span>
          </button>
          <ul className={`nav-menu ${isMenuOpen ? 'open' : ''}`}>
            <li><a href="#" onClick={() => { setActivePage('home'); setIsMenuOpen(false); }}>首页</a></li>
            <li><a href="https://ruyuan-521.github.io/" target="_blank" rel="noopener noreferrer">关于我</a></li>
            <li><a href="#" onClick={() => { setActivePage('projects'); setIsMenuOpen(false); }}>我的项目</a></li>
            <li><a href="#" onClick={() => { setActivePage('album'); setIsMenuOpen(false); }}>相册</a></li>
            <li><a href="#" onClick={() => { setActivePage('messages'); setIsMenuOpen(false); }}>留言板</a></li>
            <li><a href="#" onClick={() => { setActivePage('admin'); setIsMenuOpen(false); }}>后台管理</a></li>
          </ul>
        </nav>
      </header>
      <main className="container">
        {renderPage()}
      </main>
      <footer>
        <p>&copy; 2026 个人网站. 保留所有权利.</p>
      </footer>
    </div>
  );
}

export default App