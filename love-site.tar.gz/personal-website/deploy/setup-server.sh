#!/bin/bash
set -e

echo "===== 1. 更新系统 ====="
apt-get update && apt-get upgrade -y

echo "===== 2. 安装 Node.js 20.x ====="
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo "Node.js 版本: $(node -v)"
echo "npm 版本: $(npm -v)"

echo "===== 3. 安装 PM2 ====="
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
fi
echo "PM2 版本: $(pm2 -v)"

echo "===== 4. 安装 Nginx ====="
if ! command -v nginx &> /dev/null; then
    apt-get install -y nginx
fi
echo "Nginx 版本: $(nginx -v 2>&1)"

echo "===== 5. 创建项目目录 ====="
mkdir -p /var/www/personal-website
mkdir -p /var/log/personal-website

echo "===== 6. 配置 Nginx ====="
cp /var/www/personal-website/deploy/nginx.conf /etc/nginx/sites-available/personal-website
ln -sf /etc/nginx/sites-available/personal-website /etc/nginx/sites-enabled/personal-website
rm -f /etc/nginx/sites-enabled/default
nginx -t

echo "===== 7. 启动 Nginx ====="
systemctl enable nginx
systemctl restart nginx

echo "===== 8. 安装项目依赖 ====="
cd /var/www/personal-website
npm install --production

echo "===== 9. 使用 PM2 启动后端 ====="
pm2 start deploy/ecosystem.config.js
pm2 save
pm2 startup

echo ""
echo "===== 部署完成！ ====="
echo "网站访问地址: http://$(hostname -I | awk '{print $1}')"
echo "后端 API: http://$(hostname -I | awk '{print $1}')/api/content"
echo "管理员账号: admin"
echo "管理员密码: admin123"
echo ""
echo "常用命令:"
echo "  pm2 status          - 查看服务状态"
echo "  pm2 logs            - 查看日志"
echo "  pm2 restart all     - 重启服务"
echo "  nginx -t            - 检查 Nginx 配置"
echo "  systemctl restart nginx - 重启 Nginx"
