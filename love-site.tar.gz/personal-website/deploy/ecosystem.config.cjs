module.exports = {
  apps: [{
    name: 'personal-website',
    script: 'server.js',
    cwd: '/var/www/personal-website',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      JWT_SECRET: 'personal-website-secret-2024',
      ADMIN_PASSWORD: 'admin123'
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '200M',
    error_file: '/var/log/personal-website/error.log',
    out_file: '/var/log/personal-website/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss'
  }]
};
