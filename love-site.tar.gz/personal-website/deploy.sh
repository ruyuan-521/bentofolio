#!/bin/bash
set -e

SERVER_IP="38.244.14.175"
SERVER_USER="root"
SERVER_PASSWORD="swIqq1ugpJdpbrA2"
REMOTE_DIR="/var/www/personal-website"

echo "===== Personal Website 部署脚本 ====="
echo "目标服务器: ${SERVER_USER}@${SERVER_IP}"
echo ""

echo "===== 1. 构建前端 ====="
cd "$(dirname "$0")"
npm run build
echo "前端构建完成！"
echo ""

echo "===== 2. 上传项目文件到服务器 ====="
echo "正在上传文件..."
sshpass -p "${SERVER_PASSWORD}" ssh -o StrictHostKeyChecking=no ${SERVER_USER}@${SERVER_IP} "mkdir -p ${REMOTE_DIR}"
sshpass -p "${SERVER_PASSWORD}" scp -o StrictHostKeyChecking=no -r \
    package.json \
    package-lock.json \
    server.js \
    .env \
    dist/ \
    data/ \
    deploy/ \
    ${SERVER_USER}@${SERVER_IP}:${REMOTE_DIR}/
echo "文件上传完成！"
echo ""

echo "===== 3. 在服务器上执行初始化 ====="
sshpass -p "${SERVER_PASSWORD}" ssh -o StrictHostKeyChecking=no ${SERVER_USER}@${SERVER_IP} \
    "chmod +x ${REMOTE_DIR}/deploy/setup-server.sh && bash ${REMOTE_DIR}/deploy/setup-server.sh"

echo ""
echo "===== 部署全部完成！ ====="
echo "请访问: http://${SERVER_IP}"
