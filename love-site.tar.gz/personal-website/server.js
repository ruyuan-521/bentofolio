import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import path from 'path';
import fs from 'fs';

const app = express();
const PORT = process.env.PORT || 5000;

// ===== 数据目录 =====
const dataDir = path.join(process.cwd(), 'data');
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const usersFile = path.join(dataDir, 'users.json');
const contentFile = path.join(dataDir, 'content.json');
const messagesFile = path.join(dataDir, 'messages.json');

// ===== 文件读写工具 =====
const readJSON = (filePath, fallback) => {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    }
  } catch (e) {
    console.error(`读取文件失败 ${filePath}:`, e.message);
  }
  return fallback;
};

const writeJSON = (filePath, data) => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    console.error(`写入文件失败 ${filePath}:`, e.message);
  }
};

// ===== 配置multer存储 =====
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('只允许上传图片文件'));
    }
  }
});

// ===== 中间件 =====
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(uploadDir));
app.use(express.static(path.join(process.cwd(), 'dist')));

// ===== 初始化数据（从文件读取，不存在则用默认值） =====
let users = readJSON(usersFile, []);
let content = readJSON(contentFile, null);
let messages = readJSON(messagesFile, []);

// 初始管理员用户
const initAdmin = async () => {
  const existingAdmin = users.find(user => user.username === 'admin');
  if (!existingAdmin) {
    const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin123', 10);
    users.push({ username: 'admin', password: hashedPassword });
    writeJSON(usersFile, users);
  }
};

initAdmin();

// 初始内容
const initContent = () => {
  if (!content) {
    content = {
      about: '关于我',
      projects: [
        { id: 1, title: '项目1', description: '项目1描述' },
        { id: 2, title: '项目2', description: '项目2描述' }
      ],
      countdown: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      avatar1: '',
      avatar2: '',
      avatar1Name: '',
      avatar2Name: '',
      album: []
    };
    writeJSON(contentFile, content);
  }
};

initContent();

// ===== 路由 =====

// 登录
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = users.find(user => user.username === username);
    if (!user) {
      return res.status(401).json({ message: '用户名或密码错误' });
    }
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: '用户名或密码错误' });
    }
    const token = jwt.sign({ username: user.username }, process.env.JWT_SECRET || 'secret_key', { expiresIn: '1h' });
    res.json({ token, user: { username: user.username } });
  } catch (error) {
    res.status(500).json({ message: '服务器错误' });
  }
});

// 获取内容
app.get('/api/content', (req, res) => {
  try {
    res.json(content);
  } catch (error) {
    res.status(500).json({ message: '服务器错误' });
  }
});

// 上传头像
app.post('/api/upload-avatar', upload.single('avatar'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: '请选择要上传的文件' });
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    res.json({ url: fileUrl });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 更新内容（保存到文件）
app.put('/api/content', (req, res) => {
  try {
    if (!content) {
      return res.status(404).json({ message: '内容不存在' });
    }
    content = { ...content, ...req.body };
    writeJSON(contentFile, content);
    res.json(content);
  } catch (error) {
    res.status(500).json({ message: '服务器错误' });
  }
});

// 获取留言列表
app.get('/api/messages', (req, res) => {
  try {
    res.json(messages);
  } catch (error) {
    res.status(500).json({ message: '服务器错误' });
  }
});

// 添加留言（保存到文件）
app.post('/api/messages', (req, res) => {
  try {
    const { name, content: messageContent } = req.body;
    if (!name || !messageContent) {
      return res.status(400).json({ message: '请输入姓名和留言内容' });
    }
    const newMessage = {
      id: Date.now(),
      name,
      content: messageContent,
      createdAt: new Date()
    };
    messages.push(newMessage);
    writeJSON(messagesFile, messages);
    res.json(newMessage);
  } catch (error) {
    res.status(500).json({ message: '服务器错误' });
  }
});

// 删除留言（保存到文件）
app.delete('/api/messages/:id', (req, res) => {
  try {
    const messageId = parseInt(req.params.id);
    const initialLength = messages.length;
    messages = messages.filter(message => message.id !== messageId);
    if (messages.length < initialLength) {
      writeJSON(messagesFile, messages);
      res.json({ message: '留言删除成功' });
    } else {
      res.status(404).json({ message: '留言不存在' });
    }
  } catch (error) {
    res.status(500).json({ message: '服务器错误' });
  }
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});

// SPA 回退：所有未匹配的路由返回 index.html
app.get('/{*path}', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'dist', 'index.html'));
});
